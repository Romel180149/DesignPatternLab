package BrideDesignPattern;

public class Green implements Color{
    @Override
    public void applyColor() {
        System.out.println("Colored With BrideDesignPattern.Green");
    }
}
