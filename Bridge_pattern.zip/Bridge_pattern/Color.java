package BrideDesignPattern;

public interface Color {
    public void applyColor();
}
