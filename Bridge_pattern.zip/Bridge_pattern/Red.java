package BrideDesignPattern;

public class Red implements Color {

    @Override
    public void applyColor() {
        System.out.println("Colored With BrideDesignPattern.Red");
    }
}
