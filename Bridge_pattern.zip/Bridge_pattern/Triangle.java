package BrideDesignPattern;

public class Triangle extends Shape{
    Triangle(Color color) {
        super(color);
    }

    @Override
    public void applyColor() {
        System.out.printf("BrideDesignPattern.Triangle:");
        color.applyColor();

    }
}
