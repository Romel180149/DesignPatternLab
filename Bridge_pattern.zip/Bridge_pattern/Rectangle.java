package BrideDesignPattern;

public class Rectangle extends Shape {
    Rectangle(Color color) {
        super(color);
    }

    @Override
    public void applyColor() {
        System.out.printf("BrideDesignPattern.Rectangle:");
        color.applyColor();

    }

}
