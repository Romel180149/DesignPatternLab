package BrideDesignPattern;

public class Main {
    public static void main(String[] args) {
        Shape triangle=new Triangle(new Blue());
        triangle.applyColor();

    }


}





