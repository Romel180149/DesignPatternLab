package BrideDesignPattern;

public class Line extends Shape{

    Line(Color color) {
        super(color);
    }

    @Override
    public void applyColor() {
        System.out.printf("BrideDesignPattern.Line:");
        color.applyColor();
    }

}
