interface advanceFileSystem {
    void doc(String fileName);
    void excel(String fileName);
    void xml(String fileName);
}
