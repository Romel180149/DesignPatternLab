public class xmlFile implements advanceFileSystem{

    @Override
    public void doc(String fileName) {
        
    }

    @Override
    public void excel(String fileName) {
        
    }

    @Override
    public void xml(String fileName) {
        System.out.println("XML file open and file Name is "+fileName);
    }
    
}
