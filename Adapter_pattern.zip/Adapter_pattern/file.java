interface file{
    void openPdf(String fileType,String fileName);
}