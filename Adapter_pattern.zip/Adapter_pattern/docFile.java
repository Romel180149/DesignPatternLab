public class docFile implements advanceFileSystem{

    @Override
    public void doc(String fileName) {
        System.out.println("Doc file open and file Name is "+fileName);
    }

    @Override
    public void excel(String fileName) {
        
    }

    @Override
    public void xml(String fileName) {
        
    }
    
}
