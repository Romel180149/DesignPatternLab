import java.util.Scanner;

public class user_class {
    public static void main(String[] args) {
        try (Scanner in = new Scanner(System.in)) {
            dept d= dept.getAccess();
            System.out.println("Enter the Department of Just: ");
            String s1=in.next();
            if(s1.equalsIgnoreCase("cse"))d.cse();
            else if(s1.equalsIgnoreCase("eee"))d.eee();
            else if(s1.equalsIgnoreCase("ipe"))d.ipe();
            else d.che();
        }
    }
}
