public class dept{

    private static dept d1=new dept();
    private dept(){

    }
    public static dept getAccess(){
        return d1;
    }
    public void cse(){
        System.out.println("It is department of cse of just");
    }
    public void eee(){
        System.out.println("It is department of eee of just");
    }
    public void ipe(){
        System.out.println("It is department of ipe of just");
    }
    public void che(){
        System.out.println("It is department of che of just");
    }
}