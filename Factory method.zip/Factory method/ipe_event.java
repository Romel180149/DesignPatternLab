public class ipe_event implements dept_name{
    @Override
    public void details(){
        System.out.println("There are event of ipe dept");
    }
}
