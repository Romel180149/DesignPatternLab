public class factory {
    public void getDeptName(String name){
        if(name.equalsIgnoreCase("cse")){
            cse_event c1=new cse_event();
            c1.details();
        }
        else if(name.equalsIgnoreCase("eee")){
            eee_event e1=new eee_event();
            e1.details();
        }
        else{
            ipe_event p1=new ipe_event();
            p1.details();
        }
    }
}
