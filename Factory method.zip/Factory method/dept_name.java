interface dept_name {
    void details();
}
