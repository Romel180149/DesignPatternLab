public class cse_event implements dept_name{
    @Override
    public void details(){
        System.out.println("There are event of cse dept");
    }
}
