import java.util.Scanner;

public class user_class {
    public static void main(String[] args) {
        Scanner in=new Scanner(System.in);
        factory f1=new factory();
        System.out.println("Enter the name of Department: ");
        String s1=in.next();
        f1.getDeptName(s1);
        in.close();
    }
}
