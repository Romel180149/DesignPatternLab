package software_design_pattern_lab1.AdapterDesignPattern;

public class CalculatorAdapter {
    NormalCalculator normalCalculator = new NormalCalculator();
    BinaryCalculator binCalculator = new BinaryCalculator();
    public void calculateSum(String a, String b, String type){
        if (type.equalsIgnoreCase("Binary")){
            System.out.println(binCalculator.sum(a, b));
        }
        else{
            System.out.println(normalCalculator.sum(Integer.parseInt(a), Integer.parseInt(b)));
        }
    }
}
