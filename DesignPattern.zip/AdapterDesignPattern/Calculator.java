package software_design_pattern_lab1.AdapterDesignPattern;

public interface Calculator {
    public abstract int sum(int a,int b);
}
