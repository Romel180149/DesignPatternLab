package software_design_pattern_lab1.AdapterDesignPattern;

public class Main {
    public static void main(String[] args) {
        CalculatorAdapter calculatorAdapter = new CalculatorAdapter();

        calculatorAdapter.calculateSum("1001", "1000", "Binary");
        calculatorAdapter.calculateSum("2001", "3000", "Decimal");
    }
}
