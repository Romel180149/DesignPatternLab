package software_design_pattern_lab1.AdapterDesignPattern;

public interface BinCalculator {
    public abstract String sum(String a, String b);
}
