package software_design_pattern_lab1.AdapterDesignPattern;

public class BinaryCalculator implements BinCalculator{

    @Override
    public String sum(String a, String b) {
        int x = Integer.parseInt(a,2);
        int y = Integer.parseInt(b,2);
        return Integer.toBinaryString(x+y);
    } 
}
