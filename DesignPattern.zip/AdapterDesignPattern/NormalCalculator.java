package software_design_pattern_lab1.AdapterDesignPattern;

public class NormalCalculator implements Calculator{

    @Override
    public int sum(int a, int b) {
        return a+b;
    }
    
}
