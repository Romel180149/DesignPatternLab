package software_design_pattern_lab1.BuilderDesignPattern;

public abstract class HomeBuilder {
    private Home home;
    public Home getHome(){
        return home;
    }
    public void setHome(Home home) {
        this.home = home;
    }

    public final Home makeHome(){
        Home home = createHome();
        setHome(home);
        setFloor();
        setRoof();
        setWall();
        return home;
    }
    
    public abstract void setFloor();
    public abstract void setWall();
    public abstract void setRoof();
    public abstract Home createHome(); 
    
}
