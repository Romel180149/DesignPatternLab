package software_design_pattern_lab1.BuilderDesignPattern;

public class Home {
    String floor,wall,roof;

    public String getFloor() {
        return floor;
    }

    public void setFloor(String floor) {
        this.floor = floor;
    }

    public String getWall() {
        return wall;
    }

    public void setWall(String wall) {
        this.wall = wall;
    }

    public String getRoof() {
        return roof;
    }

    public void setRoof(String roof) {
        this.roof = roof;
    }

    @Override
    public String toString() {
        return "Home [floor=" + floor + ", roof=" + roof + ", wall=" + wall + "]";
    }
    
}
