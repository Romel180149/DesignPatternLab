package software_design_pattern_lab1.BuilderDesignPattern;

public class LaxariousHomeBuilder extends HomeBuilder{

    @Override
    public void setFloor() {
        getHome().setFloor("Concrete");
        
    }

    @Override
    public void setRoof() {
        getHome().setRoof("Concrete");
        
    }

    @Override
    public void setWall() {
        getHome().setWall("Concrete");
        
    }
    @Override
    public Home createHome() {
        return new Home();
    }
}
