package software_design_pattern_lab1.BuilderDesignPattern;

public class Customer {
    public static void main(String[] args) {
        new Contractor();
        Home normalHome = Contractor.takeContract("Normal Home");
        new Contractor();
        Home richHome = Contractor.takeContract("Rich Home");
        new Contractor();
        Home laxariousHome = Contractor.takeContract("Laxarious Home");

        System.out.println("Normal " +normalHome);
        System.out.println("Rich "+ richHome);
        System.out.println("Laxarious "+ laxariousHome);
    }
}
