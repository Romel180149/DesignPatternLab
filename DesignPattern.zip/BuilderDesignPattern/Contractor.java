package software_design_pattern_lab1.BuilderDesignPattern;

public class Contractor {
    public static Home takeContract(String homeType){
        HomeBuilder homeBuilder = null;

        if (homeType.equalsIgnoreCase("normal home")){
            homeBuilder = new NormalHomeBuilder();
        }
        else if (homeType.equalsIgnoreCase("Rich Home")){
            homeBuilder = new RichHomeBuider();
        }
        else {
            homeBuilder = new LaxariousHomeBuilder();
        }

        return homeBuilder.makeHome();
    }
}
