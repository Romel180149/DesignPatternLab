package software_design_pattern_lab1.BuilderDesignPattern;

public class RichHomeBuider extends HomeBuilder{
    @Override
    public void setFloor() {
        getHome().setFloor("Terraced");
        
    }

    @Override
    public void setRoof() {
        getHome().setRoof("Terraceed");
        
    }

    @Override
    public void setWall() {
        getHome().setWall("Bricks");
        
    }

    @Override
    public Home createHome() {
        return new Home();
    }
}
