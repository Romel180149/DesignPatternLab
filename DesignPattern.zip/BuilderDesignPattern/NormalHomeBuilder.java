package software_design_pattern_lab1.BuilderDesignPattern;

public class NormalHomeBuilder extends HomeBuilder{

    @Override
    public void setFloor() {
        getHome().setFloor("Soil");
        
    }

    @Override
    public void setRoof() {
        getHome().setRoof("Tin");
        
    }

    @Override
    public void setWall() {
        getHome().setWall("Tin");
        
    }

    @Override
    public Home createHome() {
        return new Home();
    }

}
