package software_design_pattern_lab1.MediatorDesignPattern;

public class MediatorPatternDemo {
    public static void main(String[] args) {
        User Sopon = new User("Sopon");
        User Niloy = new User("Niloy");
        Sopon.sendMessage("Hi! Topper.");
        Niloy.sendMessage("Yes! I am 3.98 and I am a Topper.");
    }
}
