package software_design_pattern_lab1.MediatorDesignPattern;

public class ChatRoom {
    public static void showMessage(User user, String message){
        System.out.println(user.getName()+" : "+message);
    }
}
