package software_design_pattern_lab1.Different_Type_of_Employee_in_a_Company;

public class Company {
    
}
