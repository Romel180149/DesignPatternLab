package software_design_pattern_lab1.IteratorDesignPattern;

public interface Container {
    abstract Iterator getIterator();
}
