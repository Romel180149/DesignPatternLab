package software_design_pattern_lab1.IteratorDesignPattern;

public class IteratorPatternDemo {
    public static void main(String[] args) {
        NameRepository name = new NameRepository();
        for (Iterator it=name.getIterator();it.hasNext();){
            String s = (String) it.next();
            System.out.println(s);
        }
    }
}
