package software_design_pattern_lab1.IteratorDesignPattern;

public class NameRepository implements Container{
    private String name[] = {"Tosiqul","Islam","Sopon"};   

    @Override
    public Iterator getIterator() {
        return new NameIterator();
    }

    private class NameIterator implements Iterator{
        int i;

        @Override
        public boolean hasNext() {
            if (i<name.length){
                return true;
            }
            return false;
        }

        @Override
        public Object next() {
            if (i<name.length){
                return name[i++];
            }
            return null;
        }
        
    }
}
