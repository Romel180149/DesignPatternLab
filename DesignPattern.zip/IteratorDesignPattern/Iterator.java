package software_design_pattern_lab1.IteratorDesignPattern;

public interface Iterator {
    abstract boolean hasNext();
    abstract Object next();
}
