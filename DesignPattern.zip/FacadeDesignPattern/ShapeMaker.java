package software_design_pattern_lab1.FacadeDesignPattern;

public class ShapeMaker {
    private Shape circle,rectangle;
    public ShapeMaker(){
        circle = new Circle();
        rectangle = new Rectangle();
    }
    public void makeCircle(){
        circle.draw();
    }
    public void makeRectangle(){
        rectangle.draw();
    }
}
