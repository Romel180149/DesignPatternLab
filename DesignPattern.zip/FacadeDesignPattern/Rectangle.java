package software_design_pattern_lab1.FacadeDesignPattern;

public class Rectangle implements Shape{

    @Override
    public void draw() {
        System.out.println("Rectangle is drewn");
    }
}
