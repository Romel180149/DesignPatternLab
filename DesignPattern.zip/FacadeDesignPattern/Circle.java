package software_design_pattern_lab1.FacadeDesignPattern;

public class Circle implements Shape{

    @Override
    public void draw() {
        System.out.println("Circle is drawn");
    }
    
}
