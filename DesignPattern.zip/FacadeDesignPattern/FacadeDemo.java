package software_design_pattern_lab1.FacadeDesignPattern;

public class FacadeDemo {
    public static void main(String[] args) {
        ShapeMaker shapeMaker = new ShapeMaker();
        shapeMaker.makeCircle();
        shapeMaker.makeRectangle();
    }
}
