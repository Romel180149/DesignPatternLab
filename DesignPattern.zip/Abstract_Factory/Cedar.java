package software_design_pattern_lab1.Abstract_Factory;

public class Cedar implements Tree{

    @Override
    public void charactaristics() {
        System.out.println("They are tall trees with large trunks and massive, irregular heads of spreading branches. Young trees are covered with smooth, dark-gray bark that becomes brown, fissured, and scaly with age.");
        
    }

    @Override
    public void scientificName() {
        System.out.println("Cedrus");
        
    }
    
}
