package software_design_pattern_lab1.Abstract_Factory;

public class Pine implements Tree{

    @Override
    public void charactaristics() {
        System.out.println("pine, Any of 10 genera of coniferous trees (rarely shrubs) of the family Pinaceae (see conifer), native to northern temperate regions, especially about 90 species of ornamental and timber evergreen conifers of the genus Pinus. Needlelike leaves and cones are solitary or in bunches. Shallow root systems make pines susceptible to wind and surface disturbance. The family includes fir, Douglas fir, hemlock, spruce, larch, and cedar. Many species are sources of softwood timber, paper pulp, oils, and resins. Some are cultivated as ornamentals.");
        
    }

    @Override
    public void scientificName() {
        System.out.println("Pinus");
        
    }
    
}
