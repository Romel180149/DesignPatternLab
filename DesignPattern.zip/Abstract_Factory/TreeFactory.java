package software_design_pattern_lab1.Abstract_Factory;

public class TreeFactory {

    public TreeTypeFactory getTreeType(String type){
        if (type.equals("Softwood")){
            return new SoftwoodTreeFactory();
        }
        else if (type.equals("Hardwood")){
            return new HardwoodTreeFactory();
        }
        return null;
    }
}
