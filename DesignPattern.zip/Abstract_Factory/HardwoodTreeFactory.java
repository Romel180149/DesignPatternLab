package software_design_pattern_lab1.Abstract_Factory;

public class HardwoodTreeFactory implements TreeTypeFactory{

    @Override
    public Tree getTree(String treeType) {
        if("Maple".equals(treeType)){
            return new Maple();
        }
        else if ("Teak".equals(treeType)){
            return new Teak();
        }
        return null;
    }
    
}
