package software_design_pattern_lab1.Abstract_Factory;

public class App {
    public static void main(String[] args) {
        TreeFactory treeFactory = new TreeFactory();

        TreeTypeFactory treeTypeFactory1 = treeFactory.getTreeType("Hardwood");

        TreeTypeFactory treeTypeFactory2 = new TreeFactory().getTreeType("Softwood");

        Tree tree1 = treeTypeFactory1.getTree("Maple");
        tree1.charactaristics();
        tree1.scientificName();
        System.out.println();
        Tree tree2 = treeTypeFactory1.getTree("Teak");
        tree2.charactaristics();
        tree2.scientificName();
        System.out.println();
        Tree tree3 = treeTypeFactory2.getTree("Pine");
        tree3.charactaristics();
        tree3.scientificName();
        System.out.println();
        Tree tree4 = treeTypeFactory2.getTree("Cedar");
        tree4.charactaristics();
        tree4.scientificName();
        System.out.println();

    }
}
