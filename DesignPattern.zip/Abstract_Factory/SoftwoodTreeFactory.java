package software_design_pattern_lab1.Abstract_Factory;

public class SoftwoodTreeFactory implements TreeTypeFactory{

    @Override
    public Tree getTree(String treeType) {
        if("Pine".equals(treeType)){
            return new Pine();
        }
        else if ("Cedar".equals(treeType)){
            return new Cedar();
        }
        return null;
    }
    
}
