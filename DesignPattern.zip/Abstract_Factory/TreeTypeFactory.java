package software_design_pattern_lab1.Abstract_Factory;

public interface TreeTypeFactory{

    public abstract Tree getTree(String treeType);
}
