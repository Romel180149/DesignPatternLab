package software_design_pattern_lab1.Abstract_Factory;

public class Maple implements Tree{

    @Override
    public void charactaristics() {
        System.out.println("A tree of Hardwood factory.");
        
    }

    @Override
    public void scientificName() {
        System.out.println("Acer");
        
    }
    
}
