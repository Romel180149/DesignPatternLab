package software_design_pattern_lab1.Abstract_Factory;

public interface Tree {
    public abstract void scientificName();
    public abstract void charactaristics();
}
