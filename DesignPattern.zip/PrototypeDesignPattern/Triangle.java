package software_design_pattern_lab1.PrototypeDesignPattern;

public class Triangle extends Shape{
    public Triangle() {
        this.shapeName = "Triangle";
    }
    @Override
    void draw() {
        System.out.println("Triangle is drawn");
    }
}
