package software_design_pattern_lab1.PrototypeDesignPattern;

public class Prototype {
    public static void main(String[] args) {
        ShapeStore.getShape("Circle").draw();
        ShapeStore.getShape("Triangle").draw();
        ShapeStore.getShape("Circle").draw();
    }
}
