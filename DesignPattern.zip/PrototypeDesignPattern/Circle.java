package software_design_pattern_lab1.PrototypeDesignPattern;

public class Circle extends Shape{
    public Circle() {
        this.shapeName = "Circle";
    }
    @Override
    void draw() {
        System.out.println("Cirle is drawn");
    }
}
