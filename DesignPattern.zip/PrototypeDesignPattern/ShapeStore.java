package software_design_pattern_lab1.PrototypeDesignPattern;

import java.util.HashMap;
import java.util.Map;

public class ShapeStore {
    private static Map<String,Shape>shapeMap = new HashMap<String, Shape>();
    static{
        shapeMap.put("Triangle",new Triangle());
        shapeMap.put("Circle", new Circle());
    }
    public static Shape getShape(String name){
        return (Shape) shapeMap.get(name).clone();
    }
}
