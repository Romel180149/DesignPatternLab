package software_design_pattern_lab1.PrototypeDesignPattern;

abstract class Shape implements Cloneable
{
    public String shapeName;
    abstract void draw();

    public Object clone(){
        Object clone = null;
        try{
            clone = super.clone();
        }
        catch(CloneNotSupportedException e){
            System.out.println(e);
        }
        return clone;
    }
}
