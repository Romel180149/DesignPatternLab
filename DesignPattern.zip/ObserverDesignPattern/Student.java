package software_design_pattern_lab1.ObserverDesignPattern;

public class Student {
    private String name;
    Dept dept = new Dept();
    
    Student (String name){
        this.name = name;
    }
    public void ClassUpdate(){
        System.out.println("Hey! "+name+" "+dept.courseName+" class at "+dept.time);
    }
}
