package software_design_pattern_lab1.ObserverDesignPattern;

public class ObserverPatternDemo {
    public static void main(String[] args) {
        Dept cse = new Dept("CSE");
        Student sopon = new Student("Sopon");
        Student niloy = new Student("Niloy");
        cse.admit(sopon);
        cse.admit(niloy);
        cse.setClass("Design Pattern", "9.20 am");
    }
}
