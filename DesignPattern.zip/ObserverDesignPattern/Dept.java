package software_design_pattern_lab1.ObserverDesignPattern;

import java.util.ArrayList;

public class Dept {
    ArrayList<Student> students = new ArrayList<>();
    private String name;
    public String courseName,time;
    Dept(){

    }
    Dept(String name){
        this.name = name;
    }
    public void admit(Student s){
        students.add(s);
    }
    public void NotifyStudents(){
        for (int i=0;i<students.size();i++){
            Student student = students.get(i);
            student.ClassUpdate();
        }
    }
    public void setClass(String courseName,String time){
        this.time = time;
        this.courseName = courseName;
        NotifyStudents();
    }
    
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }

    
}
