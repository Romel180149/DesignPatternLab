package software_design_pattern_lab1.SingleTonDesignPattern;

public class Main {
    public static void main(String[] args) {
        GetAmount a = GetAmount.getInstance(10);
        GetAmount b = GetAmount.getInstance(20);
        System.out.println(a.getAmount());
        System.out.println(b.getAmount());
        a.addAmount(50);
        System.out.println(a.getAmount());
        b.addAmount(30);
        System.out.println(b.getAmount());
    }
}
