package software_design_pattern_lab1.SingleTonDesignPattern;

public class GetAmount {
    private int amount=0;
    private static GetAmount getAmount;
    private GetAmount(int amount){
        this.amount = amount;
    }

    public static GetAmount getInstance(int amount){
        if (getAmount == null){
            getAmount = new GetAmount(amount);
        }
        return getAmount;
    }

    public void addAmount(int add){
        amount = amount+add;
    }

    public void decreaseAmount(int decrease){
        amount = amount-decrease;
    }

    public int getAmount() {
        return amount;
    }

}
