package software_design_pattern_lab1.SingleResponsibilityPrinciple;

public class LoanService {
    public void getLoanInterestInfo(String loanType) {
        if (loanType.equalsIgnoreCase("homeLoan")) {
            //do some job
            System.out.println("Home Loan");
        }
        if (loanType.equalsIgnoreCase("personalLoan")) {
            //do some job
            System.out.println("Personal Loan");
        }
        if (loanType.equalsIgnoreCase("car")) {
            //do some job
            System.out.println("Car Loan");
        }
        if (loanType.equalsIgnoreCase("student")){
            //do some job
            System.out.println("Student Loan");
        }

    }
}
