package software_design_pattern_lab1.SingleResponsibilityPrinciple;

public class BankService {

    PrintPassbook pPassbook = new PrintPassbook();
    LoanService lService = new LoanService();
    NotificationService nService = new NotificationService();

    public long deposit(long amount, String accountNo) {
        //deposit amount
        System.out.println(amount+" deposited to "+accountNo);
        return 0;
    }

    public long withDraw(long amount, String accountNo) {
        //withdraw amount
        System.out.println(amount +" withdraw from "+accountNo);
        return 0;
    }

}
