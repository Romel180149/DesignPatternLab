package software_design_pattern_lab1.SingleResponsibilityPrinciple;

public class PrintPassbook {
    public void printPassbook() {
        //update transaction info in passbook
        System.out.println("Transaction Info");
    }
}
