package software_design_pattern_lab1.SingleResponsibilityPrinciple;

public class App {
    public static void main(String[] args) {
        BankService bService = new BankService();
        bService.nService.sendOTP("email");
        bService.lService.getLoanInterestInfo("student");
        
    }
}
