package software_design_pattern_lab1.SingleResponsibilityPrinciple;

public class NotificationService {
    public void sendOTP(String medium) {
        if (medium.equals("email")) {
            //write email related logic
            //use JavaMailSenderAPI
            System.out.println("OTP send via Email");
        }
        if (medium.equals("phoneNumber")) {
            //write email related logic
            //use JavaMailSenderAPI
            System.out.println("OTP send via Phone Number");
        }
    }
}
