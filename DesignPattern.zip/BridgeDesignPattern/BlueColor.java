package software_design_pattern_lab1.BridgeDesignPattern;

public class BlueColor implements Color{
    @Override
    public void fillColor(){
        System.out.println("Filled by BlueColor.");
    }
}
