package software_design_pattern_lab1.BridgeDesignPattern;

public class Circle extends Shape{
    public Circle(Color color) {
        super(color);
    }
    @Override
    public void fillIt(){
        System.out.print("Circle is ");
        color.fillColor();
    }
}
