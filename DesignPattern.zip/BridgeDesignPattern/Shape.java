package software_design_pattern_lab1.BridgeDesignPattern;

public abstract class Shape {
    Color color;
    public Shape(Color color) {
        this.color = color;
    }
    public abstract void fillIt();
}
