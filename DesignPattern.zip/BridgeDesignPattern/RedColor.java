package software_design_pattern_lab1.BridgeDesignPattern;

public class RedColor implements Color{

    @Override
    public void fillColor() {
        System.out.println("Filled by Red Color.");        
    }
    
}
