package software_design_pattern_lab1.BridgeDesignPattern;

public class Rectangle extends Shape{
    public Rectangle(Color color) {
        super(color);
    }
    @Override
    public void fillIt(){
        System.out.print("Rectangle is ");
        color.fillColor();
    }
}
