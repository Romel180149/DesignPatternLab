package software_design_pattern_lab1.BridgeDesignPattern;

public interface Color {
    public abstract void fillColor();
}
