package software_design_pattern_lab1.FactoryDesignPattern;

public class SecondSemesterResult implements Result{

    @Override
    public double getResult() {
        return 3.53;
    }
}
