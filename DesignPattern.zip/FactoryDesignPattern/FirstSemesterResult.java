package software_design_pattern_lab1.FactoryDesignPattern;

public class FirstSemesterResult implements Result{

    @Override
    public double getResult() {
        return 3.63;
    }
    
}
