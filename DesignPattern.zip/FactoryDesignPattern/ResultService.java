package software_design_pattern_lab1.FactoryDesignPattern;

public class ResultService {
    public static void main(String[] args) {
        ResultFactory resultFactory = new ResultFactory();
        Result result1 = resultFactory.createResult("1st");
        Result result2 = resultFactory.createResult("2nd");
        Result result3 = resultFactory.createResult("3rd");

        System.out.println(result1.getResult());
        System.out.println(result2.getResult());
        System.out.println(result3.getResult());
    }
}
