package software_design_pattern_lab1.FactoryDesignPattern;

public class ResultFactory {
    public Result createResult(String semester){
        switch(semester){
            case "1st":
                return new FirstSemesterResult();
            case "2nd":
                return new SecondSemesterResult();
            case "3rd":
                return new ThirdSemesterResult();
            default:
                throw new IllegalArgumentException("Unknown semester"+ semester);
        }
    }
}
