package software_design_pattern_lab1.FactoryDesignPattern;

public interface Result {
    public abstract double getResult();
}
