package software_design_pattern_lab1.MementoDesignPattern;

public class Memento {
    private String state;

    public Memento(String state){
        this.state = state;
    }
    public String getState(){
        return state;
    }
}
