package software_design_pattern_lab1.MementoDesignPattern;

public class MementoDemo {
    public static void main(String[] args) {
        Originator originator = new Originator();
        CareTaker careTaker = new CareTaker();

        originator.setState("State#1");
        originator.setState("State#2");
        careTaker.add(originator.saveMemento());

        originator.setState("State#3");
        careTaker.add(originator.saveMemento());
        originator.setState("State#4");
        careTaker.add(originator.saveMemento());

        System.out.println("First Memento saved is: "+careTaker.get(0).getState());
        originator.getStateFromMemento(careTaker.get(0));
        System.out.println("First Memento saved is: "+originator.getState());
        System.out.println("Second Memento saved is: "+careTaker.get(1).getState());
        System.out.println("Third Memento saved is: "+careTaker.get(2).getState());
    }
}
