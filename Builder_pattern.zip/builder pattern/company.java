public class company{
    public void getCompany(String companyName){
        
        if(companyName.equalsIgnoreCase("bmw")){
            bmw b1 = new bmw();
            b1.getFasility();
            b1.show();
        }
        else if(companyName.equalsIgnoreCase("ode")){
            od b2=new od();
            b2.getFasility();
            b2.show();
        }
        
    }
}

