public class item {
    String engine,breaks,music,gps,battery;
    int value=0;
    public String getEngine(String engine){
        this.engine=engine;
        value+=1000;
        return engine+" engine";
    }
    public String getBreaks(String breaks){
        this.breaks=breaks;
        value+=500;
        return breaks+" breaks";
    }
    public String getMusic(String music){
        this.music=music;
        value+=600;
        return music+" Music Player";
    }
    public String getGps(String gps){
        this.gps=gps;
        value+=800;
        return gps+" GPS";
    }
    public String getBattery(String battery){
        this.battery=battery;
        value+=1500;
        return battery+" battery";
    }
    public int getValue(){
        return value;
    }
}
