public class user {
    public static void main(String[] args) {
        //System.out.println("Enter the name of car company : ");
        company c1=new company();
        c1.getCompany("bmw");
    }
}
