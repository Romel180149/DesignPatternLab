public class od extends item{
    StringBuffer s1=new StringBuffer();
    String s3;
    int totalCost=0;
    public void getFasility(){
        item Item = new item();
        String b1=Item.getEngine("Straight");
            s1.append(b1+',');
            String b2=Item.getBreaks("Drum");
            s1.append(b2+',');
            String b3=Item.getBattery("Lithiam ion");
            s1.append(b3+',');
            String b4=Item.getGps("D-GPS");
            s1.append(b4);
            int val=Item.getValue();
            totalCost+=val;
    }
    public void show(){
        s3=s1.toString();
        String s4[]=s3.split(",");
        System.out.println("The item of selected company : ");
        for(int i=0;i<s4.length;i++)
            System.out.println(s4[i]);
        System.out.println("Total cost of the car :");
        System.out.println(totalCost);
    }
}
